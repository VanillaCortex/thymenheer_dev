<?php
mysql_connect("localhost","root","") or die("No Connection");
mysql_select_db("cargo") or die("No Database name");
?>